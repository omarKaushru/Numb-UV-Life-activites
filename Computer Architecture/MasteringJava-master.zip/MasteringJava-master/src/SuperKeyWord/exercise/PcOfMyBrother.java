package SuperKeyWord.exercise;

/**
 * Created by mosharrofrubel on 1/17/17.
 */
public class PcOfMyBrother {

    public PcOfMyBrother(){
        System.out.println("Brother's Constructor: You're using PC of your brother!");
    }

}
