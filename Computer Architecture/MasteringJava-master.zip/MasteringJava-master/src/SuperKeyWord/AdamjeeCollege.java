package SuperKeyWord;

/**
 * Created by mosharrofrubel on 12/23/16.
 */
public class AdamjeeCollege {

    public AdamjeeCollege(){
        System.out.println("Constructor of Adamjee College!");
    }


    int students = 1500;


}
