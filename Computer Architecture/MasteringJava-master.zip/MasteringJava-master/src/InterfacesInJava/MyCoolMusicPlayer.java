package InterfacesInJava;

/**
 * Created by mosharrofrubel on 12/8/16.
 */
public interface MyCoolMusicPlayer {


    // to declare Interface, just use 'interface' keyword

    // just  a variable
    public static int my_age = 12;


    // a method with body. Methods can't have body in Interface
    public void my_cool_method();


}
