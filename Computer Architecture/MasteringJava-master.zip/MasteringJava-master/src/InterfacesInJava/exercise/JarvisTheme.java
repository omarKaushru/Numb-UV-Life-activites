package InterfacesInJava.exercise;

/**
 * Created by mosharrofrubel on 1/16/17.
 */
public interface JarvisTheme {

    void themeName();
    void wordpressVersion();
    void themeAuthor();

}
