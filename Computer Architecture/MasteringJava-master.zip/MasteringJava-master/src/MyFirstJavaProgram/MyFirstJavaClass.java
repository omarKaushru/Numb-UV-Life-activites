package MyFirstJavaProgram;

/**
 * Created by mosharrofrubel on 12/5/16.
 */
public class MyFirstJavaClass {
    public static void main(String[] args){

        System.out.println("Hello World! I'm learning super cool java!");

    }
}
