package MyFirstJavaProgram.exercise;

/**
 * Created by mosharrofrubel on 1/17/17.
 */
public class JavaBegins {

    public static void main(String[] args){

        System.out.println("Hi everyone!");
        System.out.println("My name is Sayan");
        System.out.println("I am learning java");
        System.out.println("Mastering Java");


        // this is a comment
    }

}
