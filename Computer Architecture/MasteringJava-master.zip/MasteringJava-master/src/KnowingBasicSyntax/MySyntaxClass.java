package KnowingBasicSyntax;

/**
 * Created by mosharrofrubel on 12/5/16.
 */

// MySyntaxClass is a java class name
public class MySyntaxClass {

    public static void main(String[] args) {

        // i want to print something on console
        System.out.println("Printing Something...");

        /*
        All Java components require names. Names used for classes, variables, and methods are called identifiers.
         */

        // Here, 'i' is  a variable name. Also an identifier.
        int i=10;
        // 'int' is a datatype. Another exercise1 of data type is 'String'
        String s = "Southeast University";



    }

    // this is a method
    public void my_favorite_method(){

    }

}
