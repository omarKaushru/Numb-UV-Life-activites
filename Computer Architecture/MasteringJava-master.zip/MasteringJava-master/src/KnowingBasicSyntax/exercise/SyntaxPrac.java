package KnowingBasicSyntax.exercise;

/**
 * Created by mosharrofrubel on 1/17/17.
 */
public class SyntaxPrac {

    public static void main(String[] args){

        int i = 10;
        String s = "Java";

        System.out.println(i);
        System.out.println(s);

        name();

    }

    public static void name(){
        System.out.println("Name is, Mosharrof Rubel");
    }

}
