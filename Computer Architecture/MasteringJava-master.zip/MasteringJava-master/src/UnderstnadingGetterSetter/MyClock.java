package UnderstnadingGetterSetter;

/**
 * Created by mosharrofrubel on 12/22/16.
 */
public class MyClock {

    private String time;

    public void setTime(String time) {
        this.time = time;
    }

    public String getTime() {
        return time;
    }


}
