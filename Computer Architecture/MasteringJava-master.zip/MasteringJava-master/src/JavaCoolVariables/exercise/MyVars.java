package JavaCoolVariables.exercise;

/**
 * Created by mosharrofrubel on 1/16/17.
 */
public class MyVars {

    static int year = 2016;

    public static void main(String[] o){

        System.out.println("Year is: "+year);

        int age = 19;
        System.out.println("Age is: "+age);

        String name = "Mosharrof Rubel";
        System.out.println("Name is: "+name);

        my_cgpa();

    }

    static void my_cgpa(){
        double cg = 2.5;
        System.out.println("CGPA is: "+cg);
    }

}
