package NonAccessModifiers;

/**
 * Created by mosharrofrubel on 12/23/16.
 */
public class Bangladesh {

    public static void main(String[] args){

        // accessing statically
        String s = Dhaka.population;
        System.out.println("Dhaka Polulation: "+s);

        Dhaka.housing();



    }

}
