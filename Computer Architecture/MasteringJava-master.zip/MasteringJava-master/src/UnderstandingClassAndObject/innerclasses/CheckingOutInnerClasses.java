package UnderstandingClassAndObject.innerclasses;

/**
 * Created by mosharrofrubel on 12/6/16.
 */
public class CheckingOutInnerClasses {


    public void test_method(){
        // method body
    }


    // this is an Inner Class
    public class OtherClass{

    }
}


