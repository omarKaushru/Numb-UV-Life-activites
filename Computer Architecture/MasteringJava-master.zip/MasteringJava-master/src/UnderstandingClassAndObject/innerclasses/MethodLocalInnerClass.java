package UnderstandingClassAndObject.innerclasses;

/**
 * Created by mosharrofrubel on 12/6/16.
 */
public class MethodLocalInnerClass {


    // this is a method
    public void testing_method_class(){


        // this is the class into a method
        class MyAwesomeMethodInnerClass {

        }

    }

}
