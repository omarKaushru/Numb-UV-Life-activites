package UnderstandingClassAndObject.SealAndFiroz;

/**
 * Created by mosharrofrubel on 12/20/16.
 */
public class Seal {

    public void name(){
        System.out.println("Firoz Ahemd");
    }

    public void designation(){
        System.out.println("CEO, Alpha Tech");
    }
    public void today_date(){
        System.out.println("31/12/2017");
    }


}
