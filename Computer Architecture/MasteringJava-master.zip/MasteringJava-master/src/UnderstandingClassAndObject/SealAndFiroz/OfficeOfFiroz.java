package UnderstandingClassAndObject.SealAndFiroz;

/**
 * Created by mosharrofrubel on 12/20/16.
 */
public class OfficeOfFiroz {

    public static void main(String[] args){

        // Creating Object
        Seal obj = new Seal();

        System.out.println("Printing Real Seal...");

        // Real Seal
        obj.name();
        obj.designation();
        obj.today_date();

    }

}
