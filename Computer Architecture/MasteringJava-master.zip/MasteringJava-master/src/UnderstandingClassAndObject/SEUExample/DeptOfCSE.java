package UnderstandingClassAndObject.SEUExample;

/**
 * Created by mosharrofrubel on 12/6/16.
 */
public class DeptOfCSE {


    public void cse_faculties(){
        System.out.println(" 1.KMH\n 2.SM\n 3.AR\n 4.RAJ");
    }

    public static void cse_classroom(){
        System.out.println("ITEDept CSE is got 30 class rooms!");
    }




    // Constructor
    public DeptOfCSE() {
    }

    /*
      Constructor is a method which has same name as class.  If there's no constructor, Java makes one automatically.
      Then, it's called default constructor.
     */

}
