package JavaConstructor;

/**
 * Created by mosharrofrubel on 12/20/16.
 */
public class Ayat {

    // this is a constructor
    Ayat(){
        System.out.println("My name is Ayat");
    }

    public static void main(String[] args){

        // creating object
        Ayat object = new Ayat();
    }

}