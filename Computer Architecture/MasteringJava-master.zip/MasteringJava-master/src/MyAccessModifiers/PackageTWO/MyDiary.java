package MyAccessModifiers.PackageTWO;

/**
 * Created by mosharrofrubel on 12/23/16.
 */
public class MyDiary {

    protected void poems(){
        System.out.println("Im poems from package two..");
    }

    void stories(){
        System.out.println("Im stories from package two..");
    }

    public void importantDates(){
        System.out.println("Im important dates from package two..");
    }

}
