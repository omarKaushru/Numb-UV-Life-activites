package MyAccessModifiers.exercise.students;

/**
 * Created by mosharrofrubel on 1/17/17.
 */
public class Student1 {

    public static int roll = 1;

}
