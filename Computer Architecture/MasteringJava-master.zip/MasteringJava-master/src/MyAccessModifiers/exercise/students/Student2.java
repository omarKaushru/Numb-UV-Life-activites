package MyAccessModifiers.exercise.students;

/**
 * Created by mosharrofrubel on 1/17/17.
 */
public class Student2 {

    public static int roll = 2;

}
