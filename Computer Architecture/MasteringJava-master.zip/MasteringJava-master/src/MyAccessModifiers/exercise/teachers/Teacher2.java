package MyAccessModifiers.exercise.teachers;

/**
 * Created by mosharrofrubel on 1/17/17.
 */
public class Teacher2 {

    static String d = "Duster";

}
