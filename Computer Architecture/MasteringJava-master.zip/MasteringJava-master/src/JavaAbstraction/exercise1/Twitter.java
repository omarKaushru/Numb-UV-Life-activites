package JavaAbstraction.exercise1;

/**
 * Created by mosharrofrubel on 1/16/17.
 */
public class Twitter extends SocialLife {
    @Override
    String socialSites() {
        return "Return from Twitter";
    }
}
