package JavaAbstraction.exercise1;

/**
 * Created by mosharrofrubel on 1/16/17.
 */
public class Facebook extends SocialLife {
    @Override
    String socialSites() {
        return "Return form Facebook";
    }
}
