package JavaAbstraction.exercise1;

/**
 * Created by mosharrofrubel on 1/16/17.
 */
public abstract class SocialLife {

    abstract String socialSites();

}
