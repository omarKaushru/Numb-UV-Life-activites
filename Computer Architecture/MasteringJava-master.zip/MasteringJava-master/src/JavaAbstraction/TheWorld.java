package JavaAbstraction;

/**
 * Created by mosharrofrubel on 12/8/16.
 */
public class TheWorld extends MyBangladesh {

    // Abstract Class can't have object , try below line by removing the comment sign
    // MyBangladesh mb = new MyBangladesh();


    @Override
    public void cool_abstract_method() {

    }

    // We extented the 'MyBangladesh' class and the abstract method is forced to use.
}
