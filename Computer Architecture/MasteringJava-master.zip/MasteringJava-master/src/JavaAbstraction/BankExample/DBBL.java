package JavaAbstraction.BankExample;

/**
 * Created by mosharrofrubel on 12/22/16.
 */
public class DBBL extends Bank {

    // this implementation is done by unknown

    @Override
    int yearly_charge() {
        return 650;
    }
}
