package JavaAbstraction.BankExample;

/**
 * Created by mosharrofrubel on 12/22/16.
 */
public abstract class Bank {
    abstract int yearly_charge();
}
