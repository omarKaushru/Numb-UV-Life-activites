package PolyMorphismBingo.exercises.dynamicPoly;

/**
 * Created by mosharrofrubel on 1/17/17.
 */
public class Cat extends Animal {

}
