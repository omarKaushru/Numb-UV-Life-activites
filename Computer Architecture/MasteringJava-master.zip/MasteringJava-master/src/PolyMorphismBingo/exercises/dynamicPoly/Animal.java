package PolyMorphismBingo.exercises.dynamicPoly;

/**
 * Created by mosharrofrubel on 1/17/17.
 */
public class Animal {

    void barking(){
        System.out.println("is barking!");
    }

}
