package PolyMorphismBingo.DynamicPolymorphism2;

/**
 * Created by mosharrofrubel on 12/21/16.
 */
    public class Audi extends Car {

        public static void main(String[] args){

            Car c;

            c = new Audi();
            c = new Car();

        }

    }
