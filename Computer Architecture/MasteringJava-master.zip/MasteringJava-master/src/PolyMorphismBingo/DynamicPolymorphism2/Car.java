package PolyMorphismBingo.DynamicPolymorphism2;

/**
 * Created by mosharrofrubel on 12/21/16.
 */
public class Car {


}
