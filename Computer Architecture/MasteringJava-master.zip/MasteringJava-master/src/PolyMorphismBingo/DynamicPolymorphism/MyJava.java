package PolyMorphismBingo.DynamicPolymorphism;

/**
 * Created by mosharrofrubel on 12/8/16.
 */
public class MyJava extends MyPython {

    public void learning_programming(){
        System.out.println("Java Learning is super cool!");
    }

}
