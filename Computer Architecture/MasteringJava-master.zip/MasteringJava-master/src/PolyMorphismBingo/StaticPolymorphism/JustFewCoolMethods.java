package PolyMorphismBingo.StaticPolymorphism;

/**
 * Created by mosharrofrubel on 12/8/16.
 */
public class JustFewCoolMethods {

    // just wrote 2 methods with same name, different parameters
    public int multiply_numbers(int a, int b){
        return a*b;
    }

    public int multiply_numbers(int a, int b, int c){
        return a*b*c;
    }

}
