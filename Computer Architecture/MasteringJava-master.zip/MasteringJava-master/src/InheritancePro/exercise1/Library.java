package InheritancePro.exercise1;

/**
 * Created by mosharrofrubel on 1/15/17.
 */
public class Library {

    void book_id(){
        System.out.println("Every book inherits a book id from library");
    }

    void book_issue_date(){
        System.out.println("Every book has a book issue date from librarian");
    }
}
