package InheritancePro.TypesOfInheritance.Hierarchical;

/**
 * Created by mosharrofrubel on 12/20/16.
 */
public class ITEDept extends SEU {


    // Both CSEDept and ITEDept classes extend SEU class, that's Hierarchical Inheritance
}
