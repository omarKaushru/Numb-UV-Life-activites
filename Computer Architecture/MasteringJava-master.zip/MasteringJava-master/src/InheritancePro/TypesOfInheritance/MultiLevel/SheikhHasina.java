package InheritancePro.TypesOfInheritance.MultiLevel;

/**
 * Created by mosharrofrubel on 12/20/16.
 */
public class SheikhHasina extends SheikhMujib {


    // SajeebWazed class extends SheikhHasina class, SheikhHasina class extends SheikhMujib class
    // this is called, Multilevel Inheritance

}
