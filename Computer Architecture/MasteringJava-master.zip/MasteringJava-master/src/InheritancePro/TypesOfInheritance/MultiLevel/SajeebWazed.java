package InheritancePro.TypesOfInheritance.MultiLevel;

/**
 * Created by mosharrofrubel on 12/20/16.
 */
public class SajeebWazed extends SheikhHasina {


    // SajeebWazed class extends SheikhHasina class, SheikhHasina class extends SheikhMujib class
    // this is called, Multilevel Inheritance

}
