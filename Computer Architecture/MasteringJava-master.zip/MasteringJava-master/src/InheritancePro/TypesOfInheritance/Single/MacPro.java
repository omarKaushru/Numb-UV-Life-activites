package InheritancePro.TypesOfInheritance.Single;

/**
 * Created by mosharrofrubel on 12/20/16.
 */
public class MacPro extends AppleCompany {

    // MacPro class extends only AppleCompany class, this is Single Inheritance

}
