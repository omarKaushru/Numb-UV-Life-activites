package InheritancePro;

/**
 * Created by mosharrofrubel on 10/26/16.
 */
public class OsbornNorman {

    int board_members = 67;

    // just declaring a method
    public void research_of_lifetime() {
        int papers = 50;
        String password = "333455";
        int others = 78;
        String access_email = "norman_secret_email@yahoo.com";

        // printing all when method is called
        System.out.println("Papers you will get: "+papers+", Password:"+password);
        System.out.println("Others: "+others+", Email: "+access_email);

    }



    // another method declaring
    public void diseases_of_harry (){
        String diseases_name = "Retroviral Hypodisplasia";
        System.out.println("Name of the diseases that Harry will have, "+diseases_name);
    }

}
