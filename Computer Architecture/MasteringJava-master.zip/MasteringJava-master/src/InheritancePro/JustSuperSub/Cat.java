package InheritancePro.JustSuperSub;

/**
 * Created by mosharrofrubel on 12/24/16.
 */
public class Cat extends Animal {

    // Subclass of Animal super class

    public static void main(String[] args){

        Cat c = new Cat();
        c.makeSound();
        c.color();
    }

}
