package InheritancePro.JustSuperSub;

/**
 * Created by mosharrofrubel on 12/24/16.
 */
public class Animal {

    // this is a Super Class

    void makeSound(){
        System.out.println("Mewwww...!");
    }

    void color(){
        System.out.println("Which and brown...!");
    }
}
