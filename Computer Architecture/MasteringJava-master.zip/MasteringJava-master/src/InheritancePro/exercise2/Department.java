package InheritancePro.exercise2;

/**
 * Created by mosharrofrubel on 1/15/17.
 */
public class Department extends Varsity {

}
