package InheritancePro.exercise2;

/**
 * Created by mosharrofrubel on 1/15/17.
 */
public class Varsity {

    void salary(){
        System.out.println("Salary of teacher goes from varsity!");
    }

    void transport(){
        System.out.println("Teachers will get transport facility");
    }

}
