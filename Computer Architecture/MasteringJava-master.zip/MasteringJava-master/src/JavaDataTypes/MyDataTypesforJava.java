package JavaDataTypes;

import java.util.Scanner;

/**
 * Created by mosharrofrubel on 12/5/16.
 */
public class MyDataTypesforJava {
    public static void main(String[] args){

        // Example of Primitive data types
        boolean result = true;
        short sho = 10;
        char capitalC = 'C';
        byte b = 100;
        double d = 4.8d;
        int i = 100000;
        long l = 156473890;
        float f = 9.494844f;
        char my_plus_sign = '+';



        // Reference/Object Data Types
        String s = "Anything in text can be kept in a string variable";
        String my_supercool_array [] = new String[20];




        // Scanner is a java class for taking inputs from console
        Scanner my_scan = new Scanner(System.in);
        // Here 'my_scan' variable is an exercise1 of Reference/Object Data Type




        // Default value of any reference variable is null.

    }
}
