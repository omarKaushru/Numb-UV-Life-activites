package JavaDataTypes.exercise;

/**
 * Created by mosharrofrubel on 1/16/17.
 */
public class DTypes {

    public static void main(String[] ar){

        int i = 9;
        String s = "My Text";
        double d = 2.4;
        char c = '*';
        long l = 450239487;
        short h = 2345;
        byte b = - 98;

        System.out.println("int value is: "+i);
        System.out.println("String value is: "+s);
        System.out.println("double value is: "+d);
        System.out.println("character value is: "+c);
        System.out.println("long value is: "+l);
        System.out.println("short value is: "+h);
        System.out.println("byte value is: "+b);


    }

}
