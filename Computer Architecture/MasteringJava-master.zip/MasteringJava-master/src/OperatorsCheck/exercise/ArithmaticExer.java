package OperatorsCheck.exercise;

/**
 * Created by mosharrofrubel on 1/17/17.
 */
public class ArithmaticExer {

    public static void main(String[] ar){

        int p = 60;
        int q = 20;

        System.out.println("p+q is "+ (p+q));
        System.out.println("p-q is "+ (p-q));
        System.out.println("p*q is "+ (p*q));
        System.out.println("p/q is "+ (p/q));
        System.out.println("p%q is "+ (p%q));

        System.out.println("p++ is "+ (p++));
        System.out.println("p-- is "+ (p--));

    }

}
