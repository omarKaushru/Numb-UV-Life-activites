package OperatorsCheck.exercise;

/**
 * Created by mosharrofrubel on 1/17/17.
 */
public class RelationalExer {

    public static void main(String[] args){

        int a = 20;
        int b = 10;

        if(a == b ) {
            // something happens
        }

        if ( a != b ) {
            // something happens
        }


        if ( a < b ) {
            // something happens
        }


        if ( a > b ) {
            // something happens
        }

        if ( a <= b ) {
            // something happens
        }

        if ( b >= a ) {
            // something happens
        }


    }

}
