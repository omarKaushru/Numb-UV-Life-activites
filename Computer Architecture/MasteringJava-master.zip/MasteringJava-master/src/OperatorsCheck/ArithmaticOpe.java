package OperatorsCheck;

/**
 * Created by mosharrofrubel on 1/17/17.
 */
public class ArithmaticOpe {

    public static void main(String[] ar){

        int x = 30;
        int y = 10;

        System.out.println("x+y = "+ (x+y));
        System.out.println("x-y = "+ (x-y));
        System.out.println("x*y = "+ (x*y));
        System.out.println("x/y = "+ (x/y));
        System.out.println("x%y = "+ (x%y));

        System.out.println("x++ = "+ (x++));
        System.out.println("x-- = "+ (x--));

    }

}
