package OperatorsCheck;

/**
 * Created by mosharrofrubel on 1/17/17.
 */
public class RelationalOpe {

    public static void main(String[] args){

        int p = 20;
        int q = 10;

        if(p == q ) {
            // something happens here
        }

        if ( p != q ) {
            // something happens
        }


        if ( p < q ) {
            // something happens
        }


        if ( p > q ) {
            // something happens
        }

        if ( p <= q ) {
            // something happens
        }

        if ( p >= q ) {
            // something happens
        }


    }

}
