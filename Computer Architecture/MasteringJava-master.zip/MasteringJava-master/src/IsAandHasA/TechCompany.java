package IsAandHasA;

/**
 * Created by mosharrofrubel on 12/20/16.
 */
public class TechCompany {


}
