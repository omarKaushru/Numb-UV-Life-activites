package IsAandHasA;

/**
 * Created by mosharrofrubel on 12/20/16.
 */




// AppleInc 'IS A' tech company, the inherited relation is IS A relation
public class AppleInc extends TechCompany {


    // Apple Inc 'HAS A' MacBook.
    private MacBook mb;
}
