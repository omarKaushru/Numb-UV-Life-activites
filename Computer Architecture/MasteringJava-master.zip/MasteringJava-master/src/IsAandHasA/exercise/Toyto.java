package IsAandHasA.exercise;

/**
 * Created by mosharrofrubel on 1/16/17.
 */
public class Toyto {

}
