package JavaCollections.LinkedList;

/**
 * Created by mosharrofrubel on 1/8/17.
 */
public class Movie {

    int mov_id;
    String name;
    double rating;
    String lead_actor;
    String lead_actress;
    String director;

    public Movie(int _id,String _name,double _rating,String _lead_actor,String _lead_acress,String _direcotr){
        mov_id = _id;
        name = _name;
        rating = _rating;
        lead_actor = _lead_actor;
        lead_actress = _lead_acress;
        director = _direcotr;
    }

}
