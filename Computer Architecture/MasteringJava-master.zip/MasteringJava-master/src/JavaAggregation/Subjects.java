package JavaAggregation;

/**
 * Created by mosharrofrubel on 12/23/16.
 */
public class Subjects {

    String bangla = "BAN";
    String english = "ENG";
}
