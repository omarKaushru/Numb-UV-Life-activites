package JavaAggregation.exercise;

/**
 * Created by mosharrofrubel on 1/16/17.
 */
public class OfficeEmployee {

    String section = "Accounts";

    public void emp_details(){
        System.out.println("Name: Rahim");
        System.out.println("Position: Manager");
        System.out.println("Salary: 40k");
        System.out.println("Age: 28");

    }

}
