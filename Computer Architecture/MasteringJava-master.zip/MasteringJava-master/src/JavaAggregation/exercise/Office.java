package JavaAggregation.exercise;

/**
 * Created by mosharrofrubel on 1/16/17.
 */
public class Office {

    public static void main(String[] args){

        OfficeEmployee employee = new OfficeEmployee();
        System.out.println("Section: "+employee.section);
        employee.emp_details();

    }

}
