package ENUMinJAVA;

/**
 * Created by mosharrofrubel on 12/23/16.
 */
public enum Heros {
    SPIDERMAN, SUPERMAN, BATMAN
}
