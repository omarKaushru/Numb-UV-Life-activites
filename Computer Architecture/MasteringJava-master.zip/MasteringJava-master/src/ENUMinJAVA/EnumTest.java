package ENUMinJAVA;

/**
 * Created by mosharrofrubel on 12/23/16.
 */
public class EnumTest {
    public static void main(String[] args){
        System.out.println(Heros.BATMAN);

        Toast.makeText("GetApplicationContext()","No internet!", Toast.TOAST.LENGTH_LONG);

    }
}
