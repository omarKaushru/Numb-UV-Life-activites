package ENUMinJAVA.exercise;

/**
 * Created by mosharrofrubel on 1/15/17.
 */
public class FavSites {

    public static void main(String[] args){

        System.out.println("Fav Site 1: "+Sites.Google);
        System.out.println("Fav Site 2: "+Sites.Facebook);
        System.out.println("Fav Site 3: "+Sites.Youtube);
        System.out.println("Fav Site 4: "+Sites.Quora);
        System.out.println("Fav Site 5: "+Sites.Linkedin);

    }

}
