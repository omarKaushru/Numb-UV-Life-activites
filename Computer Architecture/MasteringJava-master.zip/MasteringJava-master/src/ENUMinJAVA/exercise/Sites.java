package ENUMinJAVA.exercise;

/**
 * Created by mosharrofrubel on 1/15/17.
 */
public enum Sites {
    Google,Facebook,Youtube,Quora,Linkedin
}
