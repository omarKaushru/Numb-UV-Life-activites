package OverRidingAndOverLoading.exercise;

/**
 * Created by mosharrofrubel on 1/17/17.
 */
public class Garage {

    public void parking_id() {
        System.out.println("Every vachel has a parking id! ");
    }

    public void parking_slot() {
        System.out.println("Every vachel have a parking slot! ");
    }

}
