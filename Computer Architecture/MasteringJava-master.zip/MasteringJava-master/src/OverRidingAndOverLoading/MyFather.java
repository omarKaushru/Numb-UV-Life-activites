package OverRidingAndOverLoading;

/**
 * Created by mosharrofrubel on 12/8/16.
 */
public class MyFather {

    public void cars_of_my_father(){
        System.out.println("Audi, Marcedez, BMW");
    }

    public void lands_of_my_father(){
        System.out.println("Chittagong, Noakhali");
    }
}
